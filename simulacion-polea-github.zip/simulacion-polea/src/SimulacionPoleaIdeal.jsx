import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Play, Pause, RotateCcw } from 'lucide-react'

export default function SimulacionPoleaIdeal() {
  const g = 9.8
  const m1 = 1.2
  const m2 = 1.9
  const px = 38
  const xP = 260
  const yP0 = 120
  const yGround = 360
  const massW = 52
  const massH = 42
  const pulleyR = 28
  const xL = xP - pulleyR
  const xR = xP + pulleyR
  const xM1 = xL - massW / 2
  const xM2 = xR - massW / 2

  const [F, setF] = useState(30)
  const [running, setRunning] = useState(false)
  const [resetCount, setResetCount] = useState(0)
  const [state, setState] = useState({
    t: 0,
    yP: 0,
    vP: 0,
    y1: 0,
    v1: 0,
    y2: 0,
    v2: 0,
    contact: true,
    stoppedByCollision: false,
  })

  const rafRef = useRef(null)
  const lastRef = useRef(null)

  const thresholdM1 = 2 * m1 * g
  const thresholdM2 = 2 * m2 * g
  const T = F / 2

  const theory = useMemo(() => {
    if (T <= m1 * g) {
      return {
        label: 'Reposo',
        detail: 'La tensión no alcanza para levantar m1. El sistema queda quieto.',
        a1: 0,
        a2: 0,
        aP: 0,
      }
    }
    if (T <= m2 * g) {
      const a1 = (T - m1 * g) / m1
      const a2 = 0
      const aP = a1 / 2
      return {
        label: 'Suben la polea y m1',
        detail: 'Mientras m2 permanece sobre el piso, la restricción geométrica exige que la polea suba con la mitad de la aceleración de m1.',
        a1,
        a2,
        aP,
      }
    }
    const a1 = (T - m1 * g) / m1
    const a2 = (T - m2 * g) / m2
    const aP = (a1 + a2) / 2
    return {
      label: 'Suben la polea, m1 y m2',
      detail: 'La tensión supera el peso de m2. Entonces m2 pierde contacto y las tres partes móviles ascienden.',
      a1,
      a2,
      aP,
    }
  }, [T])

  useEffect(() => {
    setRunning(false)
    setState({
      t: 0,
      yP: 0,
      vP: 0,
      y1: 0,
      v1: 0,
      y2: 0,
      v2: 0,
      contact: T <= m2 * g,
      stoppedByCollision: false,
    })
    lastRef.current = null
  }, [F, resetCount, T, m2, g])

  useEffect(() => {
    if (!running) return undefined

    const step = (now) => {
      if (lastRef.current == null) lastRef.current = now
      const dt = Math.min((now - lastRef.current) / 1000, 0.016)
      lastRef.current = now

      setState((prev) => {
        const next = { ...prev }
        next.t = Math.min(prev.t + dt, 8)

        const stillInContact = prev.contact && T <= m2 * g
        const contact = stillInContact

        let a1 = 0
        let a2 = 0
        let aP = 0

        if (T <= m1 * g) {
          a1 = 0
          a2 = 0
          aP = 0
        } else if (contact) {
          a1 = (T - m1 * g) / m1
          a2 = 0
          aP = a1 / 2
        } else {
          a1 = (T - m1 * g) / m1
          a2 = (T - m2 * g) / m2
          aP = (a1 + a2) / 2
        }

        next.v1 = prev.v1 + a1 * dt
        next.v2 = contact ? 0 : prev.v2 + a2 * dt
        next.vP = prev.vP + aP * dt

        next.y1 = prev.y1 + next.v1 * dt
        next.y2 = contact ? 0 : prev.y2 + next.v2 * dt
        next.yP = prev.yP + next.vP * dt
        next.contact = contact

        const bottomOfPulley = yP0 - next.yP * px + pulleyR
        const topOfM1 = 235 - next.y1 * px

        if (topOfM1 <= bottomOfPulley) {
          const y1Collision = (235 - (yP0 + pulleyR)) / px
          next.y1 = y1Collision
          next.v1 = 0
          next.v2 = contact ? 0 : next.v2
          next.vP = 0
          next.stoppedByCollision = true
        }

        return next
      })

      rafRef.current = requestAnimationFrame(step)
    }

    rafRef.current = requestAnimationFrame(step)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      rafRef.current = null
      lastRef.current = null
    }
  }, [running, T, m1, m2, g, px])

  useEffect(() => {
    if ((state.t >= 8 || state.stoppedByCollision) && running) {
      setRunning(false)
    }
  }, [state.t, state.stoppedByCollision, running])

  const reset = () => {
    setRunning(false)
    setResetCount((v) => v + 1)
  }

  const yPulley = yP0 - state.yP * px
  const y1Top = 235 - state.y1 * px
  const y2Top = yGround - massH - state.y2 * px
  const normal = Math.max(0, m2 * g - T)
  const bottomOfPulley = yPulley + pulleyR
  const collisionReached = state.stoppedByCollision || y1Top <= bottomOfPulley

  return (
    <div className="page-shell">
      <div className="app-container">
        <div className="page-header">
          <h1>Simulación Ejercicio 6 - Práctico 4</h1>
        </div>

        <div className="main-grid">
          <section className="panel card-large">
            <div className="panel-header">
              <h2>Animación</h2>
            </div>
            <div className="panel-body">
              <div className="animation-box">
                <svg viewBox="0 0 520 430" className="sim-svg">
                  <defs>
                    <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                      <path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor" />
                    </marker>
                  </defs>

                  <line x1="0" y1={yGround} x2="520" y2={yGround} stroke="#94a3b8" strokeWidth="3" />

                  <line x1={xP} y1={yPulley - pulleyR} x2={xP} y2={yPulley - 68} stroke="#0f172a" strokeWidth="3" />
                  <line x1={xP} y1={yPulley - 68} x2={xP} y2={yPulley - 104} stroke="#0f172a" strokeWidth="3" markerEnd="url(#arrow)" />
                  <text x={xP + 12} y={yPulley - 88} className="svg-label">F</text>

                  <circle cx={xP} cy={yPulley} r={pulleyR} fill="#e2e8f0" stroke="#334155" strokeWidth="4" />
                  <circle cx={xP} cy={yPulley} r="5" fill="#334155" />

                  <path d={`M ${xL} ${yPulley} A ${pulleyR} ${pulleyR} 0 0 1 ${xR} ${yPulley}`} fill="none" stroke="#111827" strokeWidth="4" />
                  <line x1={xL} y1={yPulley} x2={xL} y2={y1Top} stroke="#111827" strokeWidth="4" />
                  <line x1={xR} y1={yPulley} x2={xR} y2={y2Top} stroke="#111827" strokeWidth="4" />

                  <rect x={xM1} y={y1Top} width={massW} height={massH} rx="4" fill="#94a3b8" stroke="#334155" strokeWidth="2" />
                  <text x={xM1 + 15} y={y1Top + 26} className="svg-label">m1</text>

                  <rect x={xM2} y={y2Top} width={massW} height={massH} rx="4" fill="#cbd5e1" stroke="#334155" strokeWidth="2" />
                  <text x={xM2 + 15} y={y2Top + 26} className="svg-label">m2</text>

                  {state.contact && <line x1={xM2} y1={yGround} x2={xM2 + massW} y2={yGround} stroke="#64748b" strokeWidth="4" />}
                </svg>
              </div>

              <div className="button-row">
                <button type="button" className="btn btn-primary" onClick={() => setRunning((v) => !v)}>
                  {running ? <Pause size={18} /> : <Play size={18} />}
                  <span>{running ? 'Pausar' : 'Iniciar'}</span>
                </button>
                <button type="button" className="btn btn-secondary" onClick={reset}>
                  <RotateCcw size={18} />
                  <span>Reiniciar</span>
                </button>
              </div>
            </div>
          </section>

          <div className="right-column">
            <section className="panel">
              <div className="panel-header">
                <h2>Control</h2>
              </div>
              <div className="panel-body">
                <div className="control-label-row">
                  <span>Fuerza aplicada F</span>
                  <strong>{F.toFixed(1)} N</strong>
                </div>
                <input
                  className="range-input"
                  type="range"
                  min="0"
                  max="70"
                  step="0.5"
                  value={F}
                  onChange={(e) => setF(Number(e.target.value))}
                />
                <div className="soft-box">
                  <div>m1 = {m1.toFixed(1)} kg</div>
                  <div>m2 = {m2.toFixed(1)} kg</div>
                  <div>g = {g.toFixed(1)} m/s²</div>
                  <div>T = F/2 = {T.toFixed(2)} N</div>
                </div>
              </div>
            </section>

            <section className="panel">
              <div className="panel-header">
                <h2>Lectura física</h2>
              </div>
              <div className="panel-body text-stack">
                <div className="outlined-box">
                  <div className="box-title">Régimen actual</div>
                  <div className="box-main">{theory.label}</div>
                  <div className="box-detail">{theory.detail}</div>
                </div>
                <div className="metrics-grid">
                  <div className="soft-box">a₁ = <strong>{theory.a1.toFixed(2)} m/s²</strong></div>
                  <div className="soft-box">a₂ = <strong>{theory.a2.toFixed(2)} m/s²</strong></div>
                  <div className="soft-box">aₚ = <strong>{theory.aP.toFixed(2)} m/s²</strong></div>
                  <div className="soft-box">N sobre m2 = <strong>{normal.toFixed(2)} N</strong></div>
                </div>
                <div className="soft-box">Tiempo: <strong>{state.t.toFixed(2)} s</strong></div>
                <div className="soft-box">Estado: <strong>{collisionReached ? 'Simulación detenida por contacto de m1 con la polea' : 'En evolución'}</strong></div>
              </div>
            </section>

            <section className="panel">
              <div className="panel-header">
                <h2>Umbrales</h2>
              </div>
              <div className="panel-body text-stack muted">
                <div>Inicio del ascenso de m1: <strong>F &gt; {thresholdM1.toFixed(2)} N</strong></div>
                <div>Pérdida de contacto de m2: <strong>F &gt; {thresholdM2.toFixed(2)} N</strong></div>
                <div>Esta versión evita el efecto visual de “cuerda elástica” y no intenta imitar una polea realista en perspectiva, sino la cinemática mínima consistente con el modelo ideal.</div>
                <div>La simulación se detiene cuando la parte superior de m1 alcanza el borde inferior de la polea, porque a partir de ese instante el modelo del ejercicio deja de describir correctamente la evolución geométrica.</div>
                <div>Cuando F supera el umbral de despegue de m2, la masa igualmente comienza desde el piso en t = 0 y recién luego asciende. La posición inicial ahora respeta esa condición.</div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  )
}
