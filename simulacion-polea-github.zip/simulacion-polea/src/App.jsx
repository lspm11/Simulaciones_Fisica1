import SimulacionPoleaIdeal from './SimulacionPoleaIdeal'

function App() {
  return <SimulacionPoleaIdeal />
}

export default App
